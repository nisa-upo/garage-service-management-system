#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define FILENAME "garage_data.txt"
#define MAX_RECORDS 200
#define MAX_NAME 50
#define MAX_PHONE 20
#define MAX_VTYPE 30
#define MAX_ISSUES 6
#define MAX_ISSUE_LEN 100
#define MAX_NOTES 6
#define MAX_NOTE_LEN 120
#define MAX_PARTS 40
#define MAX_PART_NAME 40

typedef struct {
    char name[MAX_PART_NAME];
    int qty;
    float unitPrice;
} Part;


typedef struct {
    int serviceID;
    char customerName[MAX_NAME];
    char customerPhone[MAX_PHONE];
    char vehicleName[MAX_VTYPE];
    int numIssues;
    char issues[MAX_ISSUES][MAX_ISSUE_LEN];
    /* 0 = Intake, 1 = Inspection, 2 = Diagnosis, 3 = Repairing, 4 = Completed */
    int status;
    int notesCount;
    char notes[MAX_NOTES][MAX_NOTE_LEN];
    int partsCount;
    Part parts[MAX_PARTS];
    float laborCharge;
    float partsCharge;
    float totalCharge;
} ServiceRecord;


/* Global variables */
ServiceRecord records[MAX_RECORDS];
int recordCount = 0;


/* FR */
void AddNewVehicle();
void SearchInfo();
void UpdateInfo();
void Delete();
void ServiceStatusz();
void AddNotes();
void BillCount();
void Display();
void PartsUsed();


/* Helpers And FNR */
void loadData();
void saveData();
int findRecordByServiceID(int id);
void removeNewline(char *s);
void clearInputBuffer();
int nextServiceID();
int adminLogin();
int technicianLogin();
int customerLogin();
void adminMenu();
void technicianMenu();
void customerMenu(int serviceID);
const char *statusText(int code);


int main() {
    loadData();
    char input[32];
    int choice;

    while (1) {
        printf("\n========================================\n");
        printf("        GARAGE SERVICE MANAGEMENT\n");
        printf("========================================\n");
        printf("1. Admin Login\n");
        printf("2. Technician Login\n");
        printf("3. Customer Login (by Service ID)\n");
        printf("4. Save & Exit\n");
        printf("========================================\n");
        printf("Enter choice: ");

        if (fgets(input, sizeof(input), stdin) == NULL) continue;
        if (sscanf(input, "%d", &choice) != 1)
            { printf("Invalid input!\n"); continue; }

        if (choice == 1) {
            if (adminLogin()) adminMenu();
            else printf("Admin login failed.\n");
        }
        else if (choice == 2) {
            if (technicianLogin()) technicianMenu();
            else printf("Technician login failed.\n");
        }
        else if (choice == 3) {
            int sid = customerLogin();
            if (sid != -1) customerMenu(sid);
            else printf("Customer login failed.\n");
        }
        else if (choice == 4) {
            saveData();
            printf("Data saved. Exiting...\n");
            return 0;
        }
        else {
            printf("Invalid choice.\n");
        }
    }
    return 0;
}

/* ---------- Helpers ---------- */

void removeNewline(char *str)
{
    int i = 0;
    while (str[i] != '\0')
    {
        if (str[i] == '\n' || str[i] == '\r')
        {
            str[i] = '\0';
            break;
        }
        i++;
    }
}

void clearInputBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF) ;
}

int nextServiceID() {
    int mx = 0;
    for (int i = 0; i < recordCount; i++)
    {
       if (records[i].serviceID > mx) {
        mx = records[i].serviceID;}
    }
    return mx + 1;
}

int findRecordByServiceID(int id) {
    for (int i = 0; i < recordCount; i++) if (records[i].serviceID == id) return i;
    return -1;
}

const char *statusText(int code) {
    switch (code) {
        case 0: return "Intake";
        case 1: return "Inspection";
        case 2: return "Diagnosis";
        case 3: return "Repairing";
        case 4: return "Completed";
        default: return "Unknown";
    }
}


void loadData() {
    FILE *f = fopen(FILENAME, "r");
    if (f==NULL) {
        printf("No existing data file found. Starting fresh.\n");
        recordCount = 0;
        return;
    }

    char line[256];
    recordCount = 0;

    while (fgets(line, sizeof(line), f) != NULL) {
        removeNewline(line);
        if (strcmp(line, "SERVICE_RECORD") == 0) {
            ServiceRecord r;
            memset(&r, 0, sizeof(ServiceRecord));
            if (fgets(line, sizeof(line), f) == NULL) break;
            sscanf(line, "ID: %d", &r.serviceID);

            if (fgets(line, sizeof(line), f) == NULL) break;
            removeNewline(line);
            sscanf(line, "CustomerName: %49[^\n]", r.customerName);

            if (fgets(line, sizeof(line), f) == NULL) break;
            removeNewline(line);
            sscanf(line, "CustomerPhone: %19[^\n]", r.customerPhone);

            if (fgets(line, sizeof(line), f) == NULL) break;
            removeNewline(line);
            sscanf(line, "VehicleName: %29[^\n]", r.vehicleName);

            if (fgets(line, sizeof(line), f) == NULL) break;
            sscanf(line, "NumIssues: %d", &r.numIssues);
            for (int i = 0; i < r.numIssues && i < MAX_ISSUES; i++) {
                if (fgets(line, sizeof(line), f) == NULL) break;
                removeNewline(line);
                sscanf(line, "Issue: %99[^\n]", r.issues[i]);
            }

            if (fgets(line, sizeof(line), f) == NULL) break;
            sscanf(line, "Status: %d", &r.status);

            if (fgets(line, sizeof(line), f) == NULL) break;
            sscanf(line, "NotesCount: %d", &r.notesCount);
            for (int i = 0; i < r.notesCount && i < MAX_NOTES; i++) {
                if (fgets(line, sizeof(line), f) == NULL) break;
                removeNewline(line);
                sscanf(line, "Note: %119[^\n]", r.notes[i]);
            }

            if (fgets(line, sizeof(line), f) == NULL) break;
            sscanf(line, "PartsCount: %d", &r.partsCount);
            for (int i = 0; i < r.partsCount && i < MAX_PARTS; i++) {
                if (fgets(line, sizeof(line), f) == NULL) break;
                removeNewline(line);
                sscanf(line, "Part: %39[^|]|%d|%f", r.parts[i].name, &r.parts[i].qty, &r.parts[i].unitPrice);
            }

            if (fgets(line, sizeof(line), f) == NULL) break;
            sscanf(line, "Labor: %f", &r.laborCharge);

            if (fgets(line, sizeof(line), f) == NULL) break;
            sscanf(line, "PartsCharge: %f", &r.partsCharge);

            if (fgets(line, sizeof(line), f) == NULL) break;
            sscanf(line, "Total: %f", &r.totalCharge);

            fgets(line, sizeof(line), f);

            if (recordCount < MAX_RECORDS) records[recordCount++] = r;
        }
    }

    fclose(f);
    printf("Data loaded. %d record(s) found.\n", recordCount);
}

void saveData() {
    FILE *f = fopen(FILENAME, "w");
    if (!f) { printf("Error saving data!\n"); return; }

    for (int i = 0; i < recordCount; i++) {
        ServiceRecord *r = &records[i];
        fprintf(f, "SERVICE_RECORD\n");
        fprintf(f, "ID: %d\n", r->serviceID);
        fprintf(f, "CustomerName: %s\n", r->customerName);
        fprintf(f, "CustomerPhone: %s\n", r->customerPhone);
        fprintf(f, "VehicleName: %s\n", r->vehicleName);
        fprintf(f, "NumIssues: %d\n", r->numIssues);
        for (int j = 0; j < r->numIssues; j++) fprintf(f, "Issue: %s\n", r->issues[j]);
        fprintf(f, "Status: %d\n", r->status);
        fprintf(f, "NotesCount: %d\n", r->notesCount);
        for (int j = 0; j < r->notesCount; j++) fprintf(f, "Note: %s\n", r->notes[j]);
        fprintf(f, "PartsCount: %d\n", r->partsCount);
        for (int j = 0; j < r->partsCount; j++)
            fprintf(f, "Part: %s|%d|%.2f\n", r->parts[j].name, r->parts[j].qty, r->parts[j].unitPrice);
        fprintf(f, "Labor: %.2f\n", r->laborCharge);
        fprintf(f, "PartsCharge: %.2f\n", r->partsCharge);
        fprintf(f, "Total: %.2f\n", r->totalCharge);
        fprintf(f, "END_RECORD\n");
    }

    fclose(f);
}

/* --- Login & Menus --- */

int adminLogin() {
    char correct[] = "admin123";
    char input[64];
    printf("Enter Admin password: ");
    if (fgets(input, sizeof(input), stdin) == NULL) return 0;
    removeNewline(input);
    if (strcmp(input, correct) == 0) return 1;
    return 0;
}

int technicianLogin() {
    char correct[] = "tech123";
    char input[64];
    printf("Enter Technician password: ");
    if (fgets(input, sizeof(input), stdin) == NULL) return 0;
    removeNewline(input);
    if (strcmp(input, correct) == 0) return 1;
    return 0;
}

int customerLogin() {
    char input[64];
    int sid;
    printf("Enter your Service ID: ");
    if (fgets(input, sizeof(input), stdin) == NULL) return -1;
    if (sscanf(input, "%d", &sid) != 1) return -1;
    if (findRecordByServiceID(sid) == -1) return -1;
    return sid;
}

void adminMenu() {
    char input[32];
    int choice;
    while (1) {
        printf("\n--- ADMIN MENU ---\n");
        printf("1. AddNewVehicle\n");
        printf("2. SearchInfo\n");
        printf("3. UpdateInfo\n");
        printf("4. Delete\n");
        printf("5. ServiceStatusz\n");
        printf("6. AddNotes\n");
        printf("7. BillCount\n");
        printf("8. Display\n");
        printf("9. PartsUsed\n");
        printf("10. Back to Main Menu\n");
        printf("Enter choice: ");
        if (fgets(input, sizeof(input), stdin) == NULL) continue;
        if (sscanf(input, "%d", &choice) != 1) { printf("Invalid.\n"); continue; }
        switch (choice) {
            case 1: AddNewVehicle(); break;
            case 2: SearchInfo(); break;
            case 3: UpdateInfo(); break;
            case 4: Delete(); break;
            case 5: ServiceStatusz(); break;
            case 6: AddNotes(); break;
            case 7: BillCount(); break;
            case 8: Display(); break;
            case 9: PartsUsed(); break;
            case 10: return;
            default: printf("Invalid choice.\n");
        }
    }
}

void technicianMenu() {
    char input[32];
    int choice;
    while (1) {
        printf("\n--- TECHNICIAN MENU ---\n");
        printf("1. ServiceStatusz\n");
        printf("2. AddNotes\n");
        printf("3. PartsUsed (view / add parts via BillCount by admin)\n");
        printf("4. SearchInfo\n");
        printf("5. Back to Main Menu\n");
        printf("Enter choice: ");
        if (fgets(input, sizeof(input), stdin) == NULL) continue;
        if (sscanf(input, "%d", &choice) != 1) { printf("Invalid.\n"); continue; }
        switch (choice) {
            case 1: ServiceStatusz(); break;
            case 2: AddNotes(); break;
            case 3: PartsUsed(); break;
            case 4: SearchInfo(); break;
            case 5: return;
            default: printf("Invalid choice.\n");
        }
    }
}

void customerMenu(int serviceID) {
    char input[32];
    int choice;
    while (1) {
        printf("\n--- CUSTOMER MENU (Service ID: %d) ---\n", serviceID);
        printf("1. View Service Status (summary)\n");
        printf("2. View Invoice (if completed) - full details\n");
        printf("3. Back to Main Menu\n");
        printf("Enter choice: ");
        if (fgets(input, sizeof(input), stdin) == NULL) continue;
        if (sscanf(input, "%d", &choice) != 1) { printf("Invalid.\n"); continue; }
        if (choice == 1) {
            int idx = findRecordByServiceID(serviceID);
            if (idx == -1) printf("Record not found.\n");
            else {
                ServiceRecord *r = &records[idx];
                printf("\nService ID: %d\nCustomer: %s\nVehicle: %s\nStatus: %s\nTotal Bill: %.2f\n",
                       r->serviceID, r->customerName, r->vehicleName, statusText(r->status), r->totalCharge);
            }
        } else if (choice == 2) {
            int idx = findRecordByServiceID(serviceID);
            if (idx == -1) printf("Record not found.\n");
            else {
                ServiceRecord *r = &records[idx];
                if (r->status != 4) { printf("Service not completed. Invoice available after completion.\n"); }
                else {
                    /* full invoice */
                    printf("\n--- INVOICE (Service ID: %d) ---\n", r->serviceID);
                    printf("Customer: %s | Phone: %s\n", r->customerName, r->customerPhone);
                    printf("Vehicle: %s\n", r->vehicleName);
                    printf("Status: %s\n", statusText(r->status));
                    if (r->numIssues > 0) {
                        printf("Issues:\n");
                        for (int i = 0; i < r->numIssues; i++) printf("- %s\n", r->issues[i]);
                    }
                    if (r->notesCount > 0) {
                        printf("Notes:\n");
                        for (int i = 0; i < r->notesCount; i++) printf("%d. %s\n", i+1, r->notes[i]);
                    }
                    if (r->partsCount > 0) {
                        printf("Parts used:\n");
                        for (int i = 0; i < r->partsCount; i++) {
                            Part *p = &r->parts[i];
                            printf("%d. %s | Qty:%d | Unit:%.2f | Sub:%.2f\n", i+1, p->name, p->qty, p->unitPrice, p->qty * p->unitPrice);
                        }
                    }
                    printf("Parts total: %.2f\n", r->partsCharge);
                    printf("Labor charge: %.2f\n", r->laborCharge);
                    printf("TOTAL PAYABLE: %.2f\n", r->totalCharge);
                }
            }
        } else if (choice == 3) {
            return;
        } else {
            printf("Invalid choice.\n");
        }
    }
}

/* ---------- NFR ---------- */

void AddNewVehicle() {
    if (recordCount >= MAX_RECORDS) { printf("Storage full. Cannot add.\n"); return; }
    char input[256];
    ServiceRecord r;
    memset(&r, 0, sizeof(ServiceRecord));
    r.serviceID = nextServiceID();

    printf("\n--- Add New Vehicle (Service ID: %d) ---\n", r.serviceID);

    printf("Enter Customer Name: ");
    if (fgets(input, sizeof(input), stdin) == NULL) return;
    removeNewline(input);
    if (strlen(input) == 0) { printf("Name cannot be empty.\n"); return; }
    strncpy(r.customerName, input, MAX_NAME-1);

    printf("Enter Customer Phone: ");
    if (fgets(input, sizeof(input), stdin) == NULL) return;
    removeNewline(input);
    strncpy(r.customerPhone, input, MAX_PHONE-1);

    printf("Enter Vehicle Name/Type: ");
    if (fgets(input, sizeof(input), stdin) == NULL) return;
    removeNewline(input);
    strncpy(r.vehicleName, input, MAX_VTYPE-1);

    printf("Enter number of reported issues (0-%d): ", MAX_ISSUES);
    if (fgets(input, sizeof(input), stdin) == NULL) return;
    int ni;
    if (sscanf(input, "%d", &ni) != 1 || ni < 0 || ni > MAX_ISSUES) { printf("Invalid number.\n"); return; }
    r.numIssues = ni;
    for (int i = 0; i < ni; i++) {
        printf("Issue %d: ", i+1);
        if (fgets(input, sizeof(input), stdin) == NULL) return;
        removeNewline(input);
        strncpy(r.issues[i], input, MAX_ISSUE_LEN-1);
    }

    r.status = 0; // Intake
    r.notesCount = 0;
    r.partsCount = 0;
    r.laborCharge = 0.0f;
    r.partsCharge = 0.0f;
    r.totalCharge = 0.0f;

    records[recordCount++] = r;
    saveData();
    printf("Added successfully. Service ID = %d\n", r.serviceID);
}

void SearchInfo() {
    char input[256];
    int choice;
    printf("\n--- SearchInfo ---\n");
    printf("1. Search by Service ID\n");
    printf("2. Search by Customer Name (substring)\n");
    printf("3. Search by Vehicle Name (substring)\n");
    printf("Enter choice: ");
    if (fgets(input, sizeof(input), stdin) == NULL) return;
    if (sscanf(input, "%d", &choice) != 1) { printf("Invalid.\n"); return; }

    if (choice == 1) {
        printf("Enter Service ID: ");
        if (fgets(input, sizeof(input), stdin) == NULL) return;
        int id;
        if (sscanf(input, "%d", &id) != 1) { printf("Invalid ID.\n"); return; }
        int idx = findRecordByServiceID(id);
        if (idx == -1) { printf("Record not found.\n"); return; }
        ServiceRecord *r = &records[idx];
        // Full details
        printf("\n--- Service Full Details ---\n");
        printf("Service ID : %d\n", r->serviceID);
        printf("Customer   : %s\nPhone      : %s\nVehicle    : %s\n", r->customerName, r->customerPhone, r->vehicleName);
        printf("Status     : %s\n", statusText(r->status));
        if (r->numIssues > 0) {
            printf("Issues:\n");
            for (int i = 0; i < r->numIssues; i++) printf("  - %s\n", r->issues[i]);
        }
        if (r->notesCount > 0) {
            printf("Notes:\n");
            for (int i = 0; i < r->notesCount; i++) printf("  %d. %s\n", i+1, r->notes[i]);
        }
        if (r->partsCount > 0) {
            printf("Parts:\n");
            for (int i = 0; i < r->partsCount; i++) {
                Part *p = &r->parts[i];
                printf("  %d. %s | Qty:%d | Unit:%.2f | Sub:%.2f\n", i+1, p->name, p->qty, p->unitPrice, p->qty * p->unitPrice);
            }
        }
        printf("Parts total: %.2f\n", r->partsCharge);
        printf("Labor charge: %.2f\n", r->laborCharge);
        printf("Total charge: %.2f\n", r->totalCharge);
    } else if (choice == 2) {
        printf("Enter customer name substring: ");
        if (fgets(input, sizeof(input), stdin) == NULL) return;
        removeNewline(input);
        int found = 0;
        for (int i = 0; i < recordCount; i++) {
            if (strstr(records[i].customerName, input) != NULL) {
                ServiceRecord *r = &records[i];
                /* show full details for each match */
                printf("\n--- Service Full Details (Match) ---\n");
                printf("Service ID : %d\n", r->serviceID);
                printf("Customer   : %s\nPhone      : %s\nVehicle    : %s\n", r->customerName, r->customerPhone, r->vehicleName);
                printf("Status     : %s\n", statusText(r->status));
                if (r->numIssues > 0) {
                    printf("Issues:\n");
                    for (int k = 0; k < r->numIssues; k++) printf("  - %s\n", r->issues[k]);
                }
                if (r->notesCount > 0) {
                    printf("Notes:\n");
                    for (int k = 0; k < r->notesCount; k++) printf("  %d. %s\n", k+1, r->notes[k]);
                }
                if (r->partsCount > 0) {
                    printf("Parts:\n");
                    for (int k = 0; k < r->partsCount; k++) {
                        Part *p = &r->parts[k];
                        printf("  %d. %s | Qty:%d | Unit:%.2f | Sub:%.2f\n", k+1, p->name, p->qty, p->unitPrice, p->qty * p->unitPrice);
                    }
                }
                printf("Parts total: %.2f\n", r->partsCharge);
                printf("Labor charge: %.2f\n", r->laborCharge);
                printf("Total charge: %.2f\n", r->totalCharge);
                found = 1;
            }
        }
        if (!found) printf("No matches.\n");
    } else if (choice == 3) {
        printf("Enter vehicle name substring: ");
        if (fgets(input, sizeof(input), stdin) == NULL) return;
        removeNewline(input);
        int found = 0;
        for (int i = 0; i < recordCount; i++) {
            if (strstr(records[i].vehicleName, input) != NULL) {
                ServiceRecord *r = &records[i];
                printf("\n--- Service Full Details (Match) ---\n");
                printf("Service ID : %d\n", r->serviceID);
                printf("Customer   : %s\nPhone      : %s\nVehicle    : %s\n", r->customerName, r->customerPhone, r->vehicleName);
                printf("Status     : %s\n", statusText(r->status));
                if (r->numIssues > 0) {
                    printf("Issues:\n");
                    for (int k = 0; k < r->numIssues; k++) printf("  - %s\n", r->issues[k]);
                }
                if (r->notesCount > 0) {
                    printf("Notes:\n");
                    for (int k = 0; k < r->notesCount; k++) printf("  %d. %s\n", k+1, r->notes[k]);
                }
                if (r->partsCount > 0) {
                    printf("Parts:\n");
                    for (int k = 0; k < r->partsCount; k++) {
                        Part *p = &r->parts[k];
                        printf("  %d. %s | Qty:%d | Unit:%.2f | Sub:%.2f\n", k+1, p->name, p->qty, p->unitPrice, p->qty * p->unitPrice);
                    }
                }
                printf("Parts total: %.2f\n", r->partsCharge);
                printf("Labor charge: %.2f\n", r->laborCharge);
                printf("Total charge: %.2f\n", r->totalCharge);
                found = 1;
            }
        }
        if (!found) printf("No matches.\n");
    } else {
        printf("Invalid choice.\n");
    }
}

void UpdateInfo() {
    char input[256];
    printf("\n--- UpdateInfo ---\n");
    printf("Enter Service ID to update: ");
    if (fgets(input, sizeof(input), stdin) == NULL) return;
    int id;
    if (sscanf(input, "%d", &id) != 1) { printf("Invalid ID.\n"); return; }
    int idx = findRecordByServiceID(id);
    if (idx == -1) { printf("Record not found.\n"); return; }
    ServiceRecord *r = &records[idx];

    printf("Current Customer Name: %s\n", r->customerName);
    printf("Enter new name (or press Enter to keep): ");
    if (fgets(input, sizeof(input), stdin) == NULL) return;
    removeNewline(input);
    if (strlen(input) > 0) strncpy(r->customerName, input, MAX_NAME-1);

    printf("Current Customer Phone: %s\n", r->customerPhone);
    printf("Enter new phone (or press Enter to keep): ");
    if (fgets(input, sizeof(input), stdin) == NULL) return;
    removeNewline(input);
    if (strlen(input) > 0) strncpy(r->customerPhone, input, MAX_PHONE-1);

    printf("Current Vehicle Name: %s\n", r->vehicleName);
    printf("Enter new vehicle name (or press Enter to keep): ");
    if (fgets(input, sizeof(input), stdin) == NULL) return;
    removeNewline(input);
    if (strlen(input) > 0) strncpy(r->vehicleName, input, MAX_VTYPE-1);

    printf("Do you want to change reported issues? (y/n): ");
    if (fgets(input, sizeof(input), stdin) == NULL) return;
    char c;
    if (sscanf(input, " %c", &c) == 1 && (c == 'y' || c == 'Y')) {
        printf("Enter number of issues (0-%d): ", MAX_ISSUES);
        if (fgets(input, sizeof(input), stdin) == NULL) return;
        int ni;
        if (sscanf(input, "%d", &ni) != 1 || ni < 0 || ni > MAX_ISSUES) { printf("Invalid number. Keeping old issues.\n"); }
        else {
            r->numIssues = ni;
            for (int i = 0; i < ni; i++) {
                printf("Issue %d: ", i+1);
                if (fgets(input, sizeof(input), stdin) == NULL) return;
                removeNewline(input);
                strncpy(r->issues[i], input, MAX_ISSUE_LEN-1);
            }
        }
    }

    printf("Do you want to change labor charge? (y/n): ");
    if (fgets(input, sizeof(input), stdin) == NULL) return;
    if (sscanf(input, " %c", &c) == 1 && (c == 'y' || c == 'Y')) {
        printf("Enter new labor charge: ");
        if (fgets(input, sizeof(input), stdin) == NULL) return;
        float l;
        if (sscanf(input, "%f", &l) == 1) r->laborCharge = l;
        else printf("Invalid number. Kept previous.\n");
    }

    float sumParts = 0.0f;
    for (int i = 0; i < r->partsCount; i++) sumParts += r->parts[i].qty * r->parts[i].unitPrice;
    r->partsCharge = sumParts;
    r->totalCharge = r->laborCharge + r->partsCharge;

    saveData();
    printf("Record updated and saved.\n");
}

void Delete() {
    char input[256];
    printf("\n--- Delete ---\n");
    printf("1. Delete single vehicle record by Service ID\n");
    printf("2. Delete all records of a customer (by exact customer name)\n");
    printf("Enter choice: ");
    if (fgets(input, sizeof(input), stdin) == NULL) return;
    int choice;
    if (sscanf(input, "%d", &choice) != 1) { printf("Invalid.\n"); return; }

    if (choice == 1) {
        printf("Enter Service ID to delete: ");
        if (fgets(input, sizeof(input), stdin) == NULL) return;
        int id;
        if (sscanf(input, "%d", &id) != 1) { printf("Invalid ID.\n"); return; }
        int idx = findRecordByServiceID(id);
        if (idx == -1) { printf("Record not found.\n"); return; }
        ServiceRecord *r = &records[idx];
        printf("Delete record: ID:%d | Customer:%s | Vehicle:%s ? (y/n): ", r->serviceID, r->customerName, r->vehicleName);
        if (fgets(input, sizeof(input), stdin) == NULL) return;
        char confirm;
        if (sscanf(input, " %c", &confirm) != 1 || (confirm != 'y' && confirm != 'Y')) { printf("Deletion cancelled.\n"); return; }
        for (int i = idx; i < recordCount - 1; i++) records[i] = records[i+1];
        recordCount--;
        saveData();
        printf("Record deleted successfully.\n");
    } else if (choice == 2) {
        printf("Enter exact Customer Name to delete all records: ");
        if (fgets(input, sizeof(input), stdin) == NULL) return;
        removeNewline(input);
        if (strlen(input) == 0) { printf("Name empty.\n"); return; }
        int removed = 0;
        ServiceRecord tmp[MAX_RECORDS];
        int tmpCount = 0;
        for (int i = 0; i < recordCount; i++) {
            if (strcmp(records[i].customerName, input) == 0) removed++;
            else tmp[tmpCount++] = records[i];
        }
        if (removed == 0) { printf("No records found for that customer.\n"); return; }
        printf("Found %d record(s) for %s. Delete all? (y/n): ", removed, input);
        if (fgets(input, sizeof(input), stdin) == NULL) return;
        char confirm;
        if (sscanf(input, " %c", &confirm) != 1 || (confirm != 'y' && confirm != 'Y')) { printf("Deletion cancelled.\n"); return; }
        for (int i = 0; i < tmpCount; i++) records[i] = tmp[i];
        recordCount = tmpCount;
        saveData();
        printf("All records for %s deleted. (%d removed)\n", input, removed);
    } else {
        printf("Invalid choice.\n");
    }
}

void ServiceStatusz() {
    char input[256];
    printf("\n--- ServiceStatusz ---\n");
    printf("Enter Service ID: ");
    if (fgets(input, sizeof(input), stdin) == NULL) return;
    int id;
    if (sscanf(input, "%d", &id) != 1) { printf("Invalid ID.\n"); return; }
    int idx = findRecordByServiceID(id);
    if (idx == -1) { printf("Record not found.\n"); return; }
    ServiceRecord *r = &records[idx];
    printf("Current status: %s\n", statusText(r->status));
    printf("Choose new status:\n");
    printf("0. Intake\n1. Inspection\n2. Diagnosis\n3. Repairing\n4. Completed\n");
    printf("Enter status number: ");
    if (fgets(input, sizeof(input), stdin) == NULL) return;
    int s;
    if (sscanf(input, "%d", &s) != 1 || s < 0 || s > 4) { printf("Invalid status.\n"); return; }
    r->status = s;
    saveData();
    printf("Status updated to: %s\n", statusText(r->status));
}

void AddNotes() {
    char input[256];
    printf("\n--- AddNotes ---\n");
    printf("Enter Service ID: ");
    if (fgets(input, sizeof(input), stdin) == NULL) return;
    int id;
    if (sscanf(input, "%d", &id) != 1) { printf("Invalid ID.\n"); return; }
    int idx = findRecordByServiceID(id);
    if (idx == -1) { printf("Record not found.\n"); return; }
    ServiceRecord *r = &records[idx];

    if (r->notesCount >= MAX_NOTES) {
        printf("Max notes reached. You can overwrite an existing note.\n");
        printf("Existing notes:\n");
        for (int i = 0; i < r->notesCount; i++) printf("%d. %s\n", i+1, r->notes[i]);
        printf("Enter note number to overwrite (1-%d): ", MAX_NOTES);
        if (fgets(input, sizeof(input), stdin) == NULL) return;
        int n;
        if (sscanf(input, "%d", &n) != 1 || n < 1 || n > MAX_NOTES) { printf("Invalid.\n"); return; }
        printf("Enter new note: ");
        if (fgets(input, sizeof(input), stdin) == NULL) return;
        removeNewline(input);
        strncpy(r->notes[n-1], input, MAX_NOTE_LEN-1);
    } else {
        printf("Enter note to add: ");
        if (fgets(input, sizeof(input), stdin) == NULL) return;
        removeNewline(input);
        if (strlen(input) == 0) { printf("Note empty.\n"); return; }
        strncpy(r->notes[r->notesCount], input, MAX_NOTE_LEN-1);
        r->notesCount++;
    }
    saveData();
    printf("Note saved.\n");
}

void BillCount() {
    char input[256];
    printf("\n--- BillCount ---\n");
    printf("Enter Service ID: ");
    if (fgets(input, sizeof(input), stdin) == NULL) return;
    int id;
    if (sscanf(input, "%d", &id) != 1) { printf("Invalid ID.\n"); return; }
    int idx = findRecordByServiceID(id);
    if (idx == -1) { printf("Record not found.\n"); return; }
    ServiceRecord *r = &records[idx];

    printf("Current labor charge: %.2f\n", r->laborCharge);
    printf("Enter labor charge (or press Enter to keep): ");
    if (fgets(input, sizeof(input), stdin) == NULL) return;
    removeNewline(input);
    if (strlen(input) > 0) {
        float l;
        if (sscanf(input, "%f", &l) == 1) r->laborCharge = l;
        else printf("Invalid. Kept old labor.\n");
    }

    printf("Do you want to add a part? (y/n): ");
    if (fgets(input, sizeof(input), stdin) == NULL) return;
    char c;
    if (sscanf(input, " %c", &c) == 1 && (c == 'y' || c == 'Y')) {
        if (r->partsCount >= MAX_PARTS) { printf("Max parts reached.\n"); }
        else {
            printf("Enter part name: ");
            if (fgets(input, sizeof(input), stdin) == NULL) return;
            removeNewline(input);
            strncpy(r->parts[r->partsCount].name, input, MAX_PART_NAME-1);

            printf("Enter quantity: ");
            if (fgets(input, sizeof(input), stdin) == NULL) return;
            int q;
            if (sscanf(input, "%d", &q) != 1 || q <= 0) { printf("Invalid qty.\n"); return; }
            r->parts[r->partsCount].qty = q;

            printf("Enter unit price: ");
            if (fgets(input, sizeof(input), stdin) == NULL) return;
            float up;
            if (sscanf(input, "%f", &up) != 1 || up < 0) { printf("Invalid price.\n"); return; }
            r->parts[r->partsCount].unitPrice = up;

            r->partsCount++;
        }
    }

    float sum = 0.0f;
    for (int i = 0; i < r->partsCount; i++) sum += r->parts[i].qty * r->parts[i].unitPrice;
    r->partsCharge = sum;
    r->totalCharge = r->partsCharge + r->laborCharge;

    saveData();
    printf("Billing updated. Parts: %.2f | Labor: %.2f | Total: %.2f\n", r->partsCharge, r->laborCharge, r->totalCharge);
}

void Display() {
    if (recordCount == 0) { printf("No records.\n"); return; }

    printf("\n--- All Service Records (%d) ---\n\n", recordCount);
    printf("%-10s %-25s %-22s %-13s %-10s\n", "ServiceID", "Customer Name", "Vehicle Name", "Status", "Total Bill");
    printf("--------------------------------------------------------------------------------\n");
    for (int i = 0; i < recordCount; i++) {
        ServiceRecord *r = &records[i];
        printf("%-10d %-25s %-22s %-13s %10.2f\n",
               r->serviceID,
               r->customerName,
               r->vehicleName,
               statusText(r->status),
               r->totalCharge);
    }
    printf("--------------------------------------------------------------------------------\n");
}

void PartsUsed() {
    char input[256];
    printf("\n--- PartsUsed ---\n");
    printf("1. View parts for one Service ID\n");
    printf("2. View total parts used across all records\n");
    printf("Enter choice: ");
    if (fgets(input, sizeof(input), stdin) == NULL) return;
    int choice;
    if (sscanf(input, "%d", &choice) != 1) { printf("Invalid.\n"); return; }

    if (choice == 1) {
        printf("Enter Service ID: ");
        if (fgets(input, sizeof(input), stdin) == NULL) return;
        int id;
        if (sscanf(input, "%d", &id) != 1) { printf("Invalid ID.\n"); return; }
        int idx = findRecordByServiceID(id);
        if (idx == -1) { printf("Record not found.\n"); return; }
        ServiceRecord *r = &records[idx];
        printf("Parts for Service ID %d (%d parts):\n", id, r->partsCount);
        for (int i = 0; i < r->partsCount; i++) {
            Part *p = &r->parts[i];
            printf("%d. %s | Qty:%d | Unit:%.2f | Sub:%.2f\n", i+1, p->name, p->qty, p->unitPrice, p->qty * p->unitPrice);
        }
        printf("Parts total: %.2f\n", r->partsCharge);
    } else if (choice == 2) {
        int totalParts = 0;
        float totalCost = 0.0f;
        for (int i = 0; i < recordCount; i++) {
            for (int j = 0; j < records[i].partsCount; j++) {
                totalParts += records[i].parts[j].qty;
                totalCost += records[i].parts[j].qty * records[i].parts[j].unitPrice;
            }
        }
        printf("Total parts used across all records: %d\n", totalParts);
        printf("Total parts cost across all records: %.2f\n", totalCost);
    } else {
        printf("Invalid choice.\n");
    }
}

